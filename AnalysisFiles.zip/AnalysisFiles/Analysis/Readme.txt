Guidlines for the files

The folder contains two type of files: A visio folder and a excel sheet

Visio files: Depict the processing of data chunks required for thematic analysis. The head tab od each column is a theme od the codes under it. For RQ1 and RQ4 there are sub-divions as mentioned in the paper. These divisions are
represented by cicular tabs. e.g. for RQ1, in the file "RQ1Definition,vsdx", the subdivision intended function has theme requirement with code "26 system specified". Here, 26 is the index number given to each publication and their
decription can be found in the excel sheet "SLR QA n RQs(ANALYSIS1).xlsx".

SLR QA n RQs(ANALYSIS1).xlsx: Has multiple sheets.   
	1. Quality Assessment and RQs: Contains basic information on the pulication. Quality assessment answers and data chunks for each RQ.
	2. Stat Graph: Contains graph for statistical and quality assessment results
	3. Analysis1: Refines data chunks to meaningful keyword
	4. Analysis1 Stat Graph: Graphs for each RQ (not included in the publication)
	5. AnalysisGraph2: Graphs for each RQ (not included in the publication)
	6. QualityAssessment: QA questions responses evaluation
	7. QualityGraph: QA related graph
	8, RQ9: Analysis of RQ9

SLR-RefinementForm.xlsx: Graphs related to refinement steps
